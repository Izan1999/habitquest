import { useState, useEffect, useCallback } from "react";
import { Habit, Completion } from "../types";
import { format } from "date-fns";

const HABITS_KEY = "habits_data";
const COMPLETIONS_KEY = "completions_data";

export function useHabits() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [completions, setCompletions] = useState<Completion[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const savedHabits = localStorage.getItem(HABITS_KEY);
    const savedCompletions = localStorage.getItem(COMPLETIONS_KEY);
    if (savedHabits) setHabits(JSON.parse(savedHabits));
    if (savedCompletions) setCompletions(JSON.parse(savedCompletions));
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(HABITS_KEY, JSON.stringify(habits));
      localStorage.setItem(COMPLETIONS_KEY, JSON.stringify(completions));
    }
  }, [habits, completions, isLoaded]);

  const addHabit = (habit: Habit) => {
    setHabits((prev) => [...prev, habit]);
  };

  const removeHabit = (id: string) => {
    setHabits((prev) => prev.filter((h) => h.id !== id));
    setCompletions((prev) => prev.filter((c) => c.habitId !== id));
  };

  const updateHabit = useCallback((id: string, updates: Partial<Habit>) => {
    setHabits(prev => prev.map(h => h.id === id ? { ...h, ...updates } : h));
  }, []);

  const toggleCompletion = (habitId: string, date: Date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    setCompletions((prev) => {
      const exists = prev.some(
        (c) => c.habitId === habitId && c.date === dateStr
      );
      if (exists) {
        return prev.filter(
          (c) => !(c.habitId === habitId && c.date === dateStr)
        );
      } else {
        return [...prev, { habitId, date: dateStr }];
      }
    });

    return !completions.some((c) => c.habitId === habitId && c.date === format(date, "yyyy-MM-dd"));
  };

  const checkIsCompleted = (habitId: string, date: Date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    return completions.some((c) => c.habitId === habitId && c.date === dateStr);
  };

  // Gamification metrics
  const xp = completions.length * 15; // 15 XP per habit completed
  const level = Math.floor(xp / 100) + 1;
  const xpToNextLevel = 100 - (xp % 100);

  return {
    habits,
    completions,
    addHabit,
    removeHabit,
    updateHabit,
    toggleCompletion,
    checkIsCompleted,
    xp,
    level,
    xpToNextLevel,
  };
}
