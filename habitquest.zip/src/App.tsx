import { useState, useEffect, useCallback } from "react";
import { AppLayout } from "./components/AppLayout";
import { Today } from "./components/Today";
import { Stats } from "./components/Stats";
import { Settings } from "./components/Settings";
import { AddHabitModal } from "./components/AddHabitModal";
import { useHabits } from "./hooks/useHabits";
import { useTheme } from "./hooks/useTheme";
import { t } from "./lib/i18n";
import { AnimatePresence, motion } from "motion/react";
import { generateMotivation } from "./services/ai";

export default function App() {
  const [activeTab, setActiveTab] = useState<'today' | 'stats' | 'settings'>('today');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState("");
  const [isPro, setIsPro] = useState(() => localStorage.getItem('habitquest_isPro') === 'true');
  const { isDark, toggleDark, forceLight } = useTheme();

  useEffect(() => {
    localStorage.setItem('habitquest_isPro', String(isPro));
    if (!isPro && isDark) {
      forceLight();
    }
  }, [isPro, isDark, forceLight]);

  
  const { 
    habits, 
    addHabit, 
    removeHabit,
    updateHabit,
    toggleCompletion, 
    checkIsCompleted,
    completions,
    xp,
    level,
    xpToNextLevel
  } = useHabits();

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  const maxHabitsReached = !isPro && habits.length >= 5;

  const handleAddClick = () => {
    if (maxHabitsReached) {
      setToastMsg(t.limitReached);
      setTimeout(() => setToastMsg(""), 3000);
      return;
    }
    setIsAddModalOpen(true);
  };

  const handleHabitAdd = (habit: any) => {
    addHabit(habit);
    setIsAddModalOpen(false);
    
    // Background AI Task for Motivation Quote
    generateMotivation(habit.title).then(motivation => {
       updateHabit(habit.id, { motivation: motivation || "" });
    });
  };

  return (
    <AppLayout 
      activeTab={activeTab} 
      onTabChange={setActiveTab}
      onAdd={handleAddClick}
      maxHabitsReached={maxHabitsReached}
    >
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMsg && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 16 }}
            exit={{ opacity: 0, y: -50 }}
            className="absolute top-0 left-4 right-4 z-50 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3"
          >
            <span className="material-icons-round text-amber-500">workspace_premium</span>
            <span className="text-sm font-bold">{toastMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="w-full h-full relative">
        <AnimatePresence mode="wait">
          {activeTab === 'today' && (
            <motion.div 
              key="today" 
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: -10 }} 
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="absolute inset-0"
            >
              <Today 
                habits={habits}
                onToggle={toggleCompletion}
                checkIsCompleted={checkIsCompleted}
                onDelete={removeHabit}
                xp={xp}
                level={level}
                xpToNextLevel={xpToNextLevel}
                isPro={isPro}
              />
            </motion.div>
          )}
          
          {activeTab === 'stats' && (
            <motion.div 
              key="stats" 
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: -10 }} 
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="absolute inset-0"
            >
              <Stats 
                habits={habits}
                completions={completions}
                xp={xp}
                level={level}
                isDark={isDark}
                isPro={isPro}
                onUpgrade={() => {
                  setIsPro(true);
                  setToastMsg(t.welcomePro);
                  setTimeout(() => setToastMsg(""), 3000);
                }}
              />
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div 
              key="settings" 
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: -10 }} 
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="absolute inset-0"
            >
              <Settings 
                isDark={isDark} 
                toggleDark={toggleDark} 
                isPro={isPro}
                onRequirePro={() => {
                  setToastMsg(t.proRequiredDark);
                  setTimeout(() => setToastMsg(""), 3000);
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AddHabitModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
        onAdd={handleHabitAdd}
      />
    </AppLayout>
  );
}
