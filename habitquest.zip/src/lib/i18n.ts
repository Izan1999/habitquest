import { es, enUS } from "date-fns/locale";

export type Language = 'en' | 'es';

export const getDeviceLanguage = (): Language => {
  if (typeof window === 'undefined') return 'en';
  const userLang = navigator.language || (navigator as any).userLanguage;
  if (!userLang) return 'en';
  const lang = userLang.split('-')[0];
  return lang === 'es' ? 'es' : 'en';
};

export const currentLang = getDeviceLanguage();
export const locale = currentLang === 'es' ? es : enUS;

export const t = {
  en: {
    limitReached: "Limit of 5 habits (Free Plan)",
    welcomePro: "Welcome to Pro Mode!",
    proRequiredDark: "Dark mode requires Pro Plan",
    today: "Today",
    blankSlateTitle: "All clear",
    blankSlateDesc: "Create your first habit below.",
    deleteHabitTitle: "Delete habit?",
    deleteHabitDesc: (name: string) => `You are about to delete "${name}". This action cannot be undone.`,
    cancel: "Cancel",
    delete: "Delete",
    newHabit: "New Habit",
    habitPlaceholder: "What habit do you want to build?",
    style: "Style",
    alertTime: "Alert Time",
    optional: "Optional",
    saveHabit: "Save Habit",
    proStatsTitle: "Pro Statistics",
    proStatsDesc: "Level up. Unlock advanced streak charts, unlimited history, and analysis of your victories.",
    unlockPro: "Unlock Pro",
    progress: "Progress",
    level: "Level",
    streak: "Streak",
    days: "days",
    accumulatedXp: "Accumulated Experience",
    xp: "XP",
    activity: "Activity",
    totalStats: "total",
    settings: "Settings",
    darkMode: "Dark Mode",
    reminders: "Reminders",
    soon: "SOON",
    generatingAI: "AI thinking...",
  },
  es: {
    limitReached: "Límite de 5 hábitos (Plan Gratis)",
    welcomePro: "¡Bienvenido al modo Pro!",
    proRequiredDark: "Modo oscuro requiere Plan Pro",
    today: "Hoy",
    blankSlateTitle: "Todo en blanco",
    blankSlateDesc: "Crea tu primer hábito abajo.",
    deleteHabitTitle: "¿Eliminar hábito?",
    deleteHabitDesc: (name: string) => `Estás a punto de eliminar "${name}". Esta acción no se puede deshacer.`,
    cancel: "Cancelar",
    delete: "Eliminar",
    newHabit: "Nuevo Hábito",
    habitPlaceholder: "¿Qué hábito quieres crear?",
    style: "Estilo",
    alertTime: "Hora de Alerta",
    optional: "Opcional",
    saveHabit: "Guardar Hábito",
    proStatsTitle: "Estadísticas Pro",
    proStatsDesc: "Asciende al siguiente nivel. Desbloquea gráficos avanzados de rachas, historial ilimitado y análisis de tus victorias.",
    unlockPro: "Desbloquear Pro",
    progress: "Progreso",
    level: "Nivel",
    streak: "Racha",
    days: "días",
    accumulatedXp: "Experiencia Acumulada",
    xp: "XP",
    activity: "Actividad",
    totalStats: "totales",
    settings: "Ajustes",
    darkMode: "Modo Oscuro",
    reminders: "Recordatorios",
    soon: "PRONTO",
    generatingAI: "IA pensando...",
  }
}[currentLang];
