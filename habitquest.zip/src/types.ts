export type Habit = {
  id: string;
  title: string;
  icon: string;
  color: string;
  reminderTime?: string;
  createdAt: number;
  motivation?: string;
};

export type Completion = {
  habitId: string;
  date: string; // YYYY-MM-DD
};
