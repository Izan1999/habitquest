import React, { useState, useMemo } from "react";
import { Habit } from "../types";
import { format } from "date-fns";
import { t, locale } from "../lib/i18n";
import { cn } from "../lib/utils";
import confetti from "canvas-confetti";
import { motion, AnimatePresence } from "motion/react";

interface TodayProps {
  habits: Habit[];
  onToggle: (id: string, date: Date) => void;
  checkIsCompleted: (id: string, date: Date) => boolean;
  onDelete: (id: string) => void;
  xp: number;
  level: number;
  xpToNextLevel: number;
  isPro?: boolean;
}

export function Today({ habits, onToggle, checkIsCompleted, onDelete, xp, level, xpToNextLevel, isPro = false }: TodayProps) {
  const today = new Date();
  
  const [deletingHabit, setDeletingHabit] = useState<Habit | null>(null);

  const completedCount = useMemo(() => {
    return habits.filter(h => checkIsCompleted(h.id, today)).length;
  }, [habits, checkIsCompleted, today]);

  const progress = habits.length === 0 ? 0 : Math.round((completedCount / habits.length) * 100);
  const strokeDashoffset = 126 - (126 * progress) / 100;

  const handleToggle = (id: string, e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;

    onToggle(id, today);
    
    if (!checkIsCompleted(id, today)) {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { x, y },
        colors: ['#6366f1', '#10b981', '#f59e0b'],
        disableForReducedMotion: true
      });
    }
  };

  return (
    <>
      <div className="flex flex-col h-full px-6 md:px-12 pt-14 md:pt-20 pb-28 md:pb-32 w-full max-w-5xl mx-auto">
        {/* Header */}
        <motion.header 
          initial={{ opacity: 0, y: -10 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="flex justify-between items-center shrink-0 mb-8"
        >
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-zinc-50">
              {t.today}
            </h1>
            <p className="text-slate-500 dark:text-zinc-400 font-medium tracking-wide text-sm mt-1 capitalize">
              {format(today, "EEEE, d MMM", { locale })}
            </p>
          </div>
          
          <div className="relative w-16 h-16 flex items-center justify-center bg-white dark:bg-transparent rounded-2xl border border-slate-200 dark:border-transparent shadow-md shadow-slate-200/60 dark:shadow-none shrink-0">
            <svg className="w-12 h-12 transform -rotate-90" viewBox="0 0 44 44">
              <circle cx="22" cy="22" r="20" fill="transparent" stroke="currentColor" strokeWidth="3" className="text-slate-100 dark:text-zinc-800" />
              <motion.circle 
                cx="22" cy="22" r="20" fill="transparent" 
                stroke="currentColor" 
                strokeWidth="4" 
                strokeDasharray="126"
                initial={{ strokeDashoffset: 126 }}
                animate={{ strokeDashoffset }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="text-indigo-500 rounded-full" 
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center gap-[1px]">
              <span className="text-xs font-extrabold text-indigo-600 dark:text-indigo-400">{habits.length}</span>
              <span className="text-[10px] font-bold text-slate-400 dark:text-zinc-500 mt-0.5 flex items-center">
                / {isPro ? <span className="material-icons-round text-[11px] ml-[1px]">all_inclusive</span> : '5'}
              </span>
            </div>
          </div>
        </motion.header>

        {/* Habits List */}
        <div className="flex-1 overflow-y-auto hide-scrollbar pb-8">
          {habits.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
              className="flex flex-col items-center justify-center h-full text-center px-4 opacity-50"
            >
              <span className="material-icons-round text-6xl text-slate-300 dark:text-zinc-700 mb-4 block">park</span>
              <p className="font-semibold text-slate-800 dark:text-zinc-300">{t.blankSlateTitle}</p>
              <p className="text-slate-500 dark:text-zinc-500 text-sm mt-1">{t.blankSlateDesc}</p>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 content-start">
              <AnimatePresence mode="popLayout">
                {habits.map((habit, i) => {
                const isCompleted = checkIsCompleted(habit.id, today);
                return (
                  <motion.div 
                    key={habit.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95, y: 15 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, x: -40 }}
                    transition={{ delay: i * 0.05, type: "spring", stiffness: 400, damping: 30 }}
                    className="relative rounded-3xl bg-red-50 dark:bg-red-950/20 overflow-hidden shadow-sm aspect-auto"
                  >
                    <div className="absolute inset-y-0 right-0 w-24 flex items-center justify-center text-red-500">
                      <span className="material-icons-round text-3xl">delete_outline</span>
                    </div>

                    <motion.div
                      drag="x"
                      dragConstraints={{ left: 0, right: 0 }}
                      dragElastic={{ left: 0.8, right: 0 }}
                      dragDirectionLock
                      onDragEnd={(e, info) => {
                        if (info.offset.x < -60) {
                          setDeletingHabit(habit);
                        }
                      }}
                      className={cn(
                        "relative flex items-center p-3 gap-4 rounded-3xl transition-colors duration-300 border",
                        isCompleted 
                          ? "bg-slate-50 dark:bg-[#09090b] border-transparent" 
                          : "bg-white dark:bg-[#18181b] border-slate-200 shadow-md shadow-slate-200/60 dark:shadow-none dark:border-zinc-800"
                      )}
                    >
                      <motion.div 
                        initial={false}
                        animate={{ 
                          opacity: isCompleted ? 0.3 : 1,
                          scale: isCompleted ? 0.9 : 1
                        }}
                        className={cn(
                          "w-12 h-12 rounded-2xl flex items-center justify-center text-white pointer-events-none shrink-0", 
                          habit.color
                        )}
                      >
                        <span className="material-icons-round text-2xl">{habit.icon}</span>
                      </motion.div>
                      
                      <motion.div 
                        animate={{ opacity: isCompleted ? 0.4 : 1 }}
                        className="flex-1 min-w-0 pointer-events-none"
                      >
                        <h3 className={cn("font-bold text-base truncate transition-all duration-300", isCompleted ? "line-through text-slate-500 dark:text-zinc-600" : "text-slate-800 dark:text-zinc-200")}>
                          {habit.title}
                        </h3>
                        {habit.reminderTime && (
                          <p className="text-[11px] font-semibold text-slate-400 dark:text-zinc-600 mt-0.5 flex items-center gap-0.5">
                            <span className="material-icons-round text-[12px]">notifications</span> 
                            {habit.reminderTime}
                          </p>
                        )}
                        {habit.motivation ? (
                          <p className="text-[11px] font-medium text-indigo-500 dark:text-indigo-400 mt-1 flex items-start gap-1 leading-tight pr-2">
                            <span className="material-icons-round text-[12px] mt-[1px]">auto_awesome</span> 
                            <span className="italic">"{habit.motivation}"</span>
                          </p>
                        ) : habit.motivation === "" ? null : (
                          <p className="text-[10px] font-medium text-slate-400 dark:text-zinc-600 mt-1 flex items-center gap-1 animate-pulse">
                            <span className="material-icons-round text-[11px]">auto_awesome</span> 
                            {t.generatingAI}
                          </p>
                        )}
                      </motion.div>

                      <motion.button
                        onPointerDown={(e) => e.stopPropagation()}
                        whileTap={{ scale: 0.8 }}
                        onClick={(e) => handleToggle(habit.id, e as any)}
                        className={cn(
                          "relative w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300 z-10",
                          isCompleted 
                            ? "bg-indigo-500 text-white shadow-md shadow-indigo-500/40 dark:shadow-none" 
                            : "bg-white dark:bg-zinc-800 border-2 border-slate-200 dark:border-zinc-700 text-slate-300 dark:text-zinc-600 hover:bg-slate-50 dark:hover:bg-zinc-700 shadow-sm shadow-slate-200/50 dark:shadow-none"
                        )}
                      >
                        <motion.span 
                          initial={false}
                          animate={{ scale: isCompleted ? 1 : 0.5, opacity: isCompleted ? 1 : 0 }}
                          className="material-icons-round font-bold"
                        >
                          check
                        </motion.span>
                      </motion.button>
                    </motion.div>
                  </motion.div>
                );
              })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {deletingHabit && (
          <div className="absolute inset-0 z-50 flex items-center justify-center px-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 dark:bg-black/60 backdrop-blur-[2px]"
              onClick={() => setDeletingHabit(null)}
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 400 }}
              className="relative bg-white dark:bg-[#18181b] rounded-3xl p-6 w-full max-w-sm shadow-2xl shadow-slate-300/50 dark:shadow-2xl border border-slate-200 dark:border-zinc-800 text-center"
            >
              <div className="w-16 h-16 bg-red-50 dark:bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="material-icons-round text-3xl">delete_forever</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-zinc-50 mb-2">{t.deleteHabitTitle}</h3>
              <p className="text-slate-500 dark:text-zinc-400 mb-6 text-sm font-medium">{t.deleteHabitDesc(deletingHabit.title)}</p>
              
              <div className="flex gap-3">
                <button 
                  onClick={() => setDeletingHabit(null)} 
                  className="flex-1 py-3.5 rounded-2xl font-bold text-slate-600 dark:text-zinc-400 bg-slate-50 dark:bg-zinc-800/50 active:scale-95 transition-transform"
                >
                  {t.cancel}
                </button>
                <button 
                  onClick={() => { onDelete(deletingHabit.id); setDeletingHabit(null); }} 
                  className="flex-1 py-3.5 rounded-2xl font-bold text-white bg-red-500 active:scale-95 transition-transform shadow-lg shadow-red-500/20"
                >
                  {t.delete}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
