import React, { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { Habit } from "../types";
import { t } from "../lib/i18n";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";

interface AddHabitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (habit: Habit) => void;
}

const COLORS = [
  "bg-red-500", "bg-orange-500", "bg-amber-500", "bg-emerald-500", 
  "bg-sky-500", "bg-indigo-500", "bg-purple-500", "bg-rose-500"
];

const ICONS = ["directions_run", "water_drop", "menu_book", "self_improvement", "restaurant", "fitness_center", "bed", "edit", "laptop_mac", "palette"];

export function AddHabitModal({ isOpen, onClose, onAdd }: AddHabitModalProps) {
  const [title, setTitle] = useState("");
  const [icon, setIcon] = useState(ICONS[0]);
  const [color, setColor] = useState(COLORS[5]);
  const [reminder, setReminder] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAdd({
      id: uuidv4(),
      title: title.trim(),
      icon,
      color,
      reminderTime: reminder || undefined,
      createdAt: Date.now(),
    });
    
    // Reset
    setTitle("");
    setIcon(ICONS[0]);
    setColor(COLORS[5]);
    setReminder("");
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end md:justify-center md:items-center pointer-events-auto md:p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-slate-900/40 dark:bg-black/70 pointer-events-auto" 
            onClick={onClose}
          />
          
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 350, damping: 30, mass: 1 }}
            style={{ willChange: "transform" }}
            className="relative bg-white dark:bg-[#09090b] w-full max-w-md md:rounded-3xl rounded-t-3xl p-6 shadow-2xl shadow-slate-300/50 dark:shadow-2xl pb-12 md:pb-6 pointer-events-auto border-t md:border border-slate-200 dark:border-zinc-800"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold tracking-tight dark:text-zinc-50">{t.newHabit}</h2>
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose} 
                className="w-8 h-8 bg-slate-100 dark:bg-zinc-800 rounded-full text-slate-500 dark:text-zinc-400 flex items-center justify-center"
              >
                <span className="material-icons-round text-[18px]">close</span>
              </motion.button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <input 
                  type="text" 
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={t.habitPlaceholder}
                  className="w-full bg-white dark:bg-[#18181b] border border-slate-200 shadow-sm shadow-slate-200/50 dark:shadow-none dark:border-zinc-800 rounded-2xl px-5 py-4 text-slate-900 dark:text-zinc-50 placeholder:text-slate-400 dark:placeholder:text-zinc-600 focus:bg-white dark:focus:bg-[#09090b] focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all font-medium text-lg"
                />
              </div>

              <div className="space-y-3 pt-2">
                <label className="text-[11px] font-bold text-slate-400 dark:text-zinc-500 uppercase tracking-wider block">{t.style}</label>
                <div className="flex items-center gap-4">
                  <motion.div 
                    key={`${color}-${icon}`}
                    initial={{ scale: 0.8, rotate: -10 }}
                    animate={{ scale: 1, rotate: 0 }}
                    className={cn("w-14 h-14 rounded-2xl flex items-center justify-center text-white shrink-0", color)}
                  >
                    <span className="material-icons-round text-3xl">{icon}</span>
                  </motion.div>
                  <div className="flex-1 flex gap-2 overflow-x-auto hide-scrollbar pb-2 mask-linear">
                    {ICONS.map((i) => (
                      <motion.button 
                        whileTap={{ scale: 0.9 }}
                        key={i} 
                        type="button"
                        onClick={() => setIcon(i)}
                        className={cn("w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center transition-colors", icon === i ? "bg-slate-900 dark:bg-white text-white dark:text-zinc-900" : "bg-slate-50 dark:bg-[#18181b] text-slate-500 dark:text-zinc-500")}
                      >
                        <span className="material-icons-round text-2xl">{i}</span>
                      </motion.button>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-3 pt-1 overflow-x-auto pb-2 hide-scrollbar">
                  {COLORS.map((c) => (
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={cn("w-8 h-8 rounded-full shrink-0 relative", c)}
                    >
                      <AnimatePresence>
                        {color === c && (
                          <motion.span 
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            exit={{ scale: 0 }}
                            className="material-icons-round text-white text-[16px] absolute inset-0 m-auto flex items-center justify-center"
                          >
                            check
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Recordatorio */}
              <div className="pt-2">
                 <div className="flex items-center justify-between bg-white dark:bg-[#18181b] border border-slate-200 shadow-sm shadow-slate-200/50 dark:shadow-none dark:border-zinc-800 rounded-2xl p-3 focus-within:border-indigo-500 focus-within:ring-4 focus-within:ring-indigo-500/10 transition-all">
                   <div className="flex items-center gap-3">
                     <div className="w-10 h-10 rounded-xl bg-white dark:bg-zinc-800/80 shadow-sm flex items-center justify-center shrink-0 border border-slate-100 dark:border-zinc-700/50">
                       <span className="material-icons-round text-slate-400 dark:text-zinc-400 text-xl">alarm</span>
                     </div>
                     <div className="flex flex-col">
                        <span className="text-[13px] font-bold text-slate-700 dark:text-zinc-200">{t.alertTime}</span>
                        <span className="text-[11px] font-medium text-slate-400 dark:text-zinc-500">{t.optional}</span>
                     </div>
                   </div>
                   
                   <div className="relative">
                     <input 
                       type="time" 
                       value={reminder}
                       onChange={(e) => setReminder(e.target.value)}
                       className="bg-transparent border-none text-slate-900 dark:text-zinc-50 font-bold text-base focus:outline-none focus:ring-0 text-right appearance-none [&::-webkit-calendar-picker-indicator]:opacity-0 [&::-webkit-calendar-picker-indicator]:absolute [&::-webkit-calendar-picker-indicator]:inset-0 [&::-webkit-calendar-picker-indicator]:w-full [&::-webkit-calendar-picker-indicator]:h-full [&::-webkit-calendar-picker-indicator]:cursor-pointer relative z-10 w-[90px]"
                     />
                   </div>
                 </div>
              </div>

              <motion.button 
                whileHover={title.trim() ? { scale: 1.02 } : {}}
                whileTap={title.trim() ? { scale: 0.98 } : {}}
                type="submit" 
                disabled={!title.trim()}
                className="w-full bg-indigo-600 text-white font-bold rounded-2xl py-4 flex items-center justify-center gap-2 disabled:opacity-50 transition-colors mt-4"
              >
                {t.saveHabit}
              </motion.button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
