import { ReactNode } from "react";
import { cn } from "../lib/utils";
import { motion } from "motion/react";

interface AppLayoutProps {
  children: ReactNode;
  activeTab: 'today' | 'stats' | 'settings';
  onTabChange: (tab: 'today' | 'stats' | 'settings') => void;
  onAdd: () => void;
  maxHabitsReached?: boolean;
}

export function AppLayout({ children, activeTab, onTabChange, onAdd, maxHabitsReached }: AppLayoutProps) {
  return (
    <div className="flex flex-col h-[100dvh] w-full md:max-w-3xl lg:max-w-5xl mx-auto bg-slate-100/60 text-slate-800 dark:bg-[#09090b] dark:text-zinc-50 overflow-hidden relative shadow-2xl transition-colors duration-500 sm:border-x sm:border-slate-200 dark:sm:border-zinc-800">
      <main className="flex-1 h-full w-full relative">
        {children}
      </main>

      {/* Floating Pill Dock */}
      <nav className="absolute bottom-8 left-1/2 -translate-x-1/2 h-16 bg-white/80 dark:bg-[#18181b]/95 backdrop-blur-2xl border border-slate-200 dark:border-zinc-800/80 p-2 rounded-full flex items-center gap-1 shadow-xl shadow-slate-300/60 dark:shadow-2xl dark:shadow-black/80 z-40">
        <NavItem
          icon="check_circle"
          isActive={activeTab === 'today'}
          onClick={() => onTabChange('today')}
        />
        <NavItem
          icon="bar_chart"
          isActive={activeTab === 'stats'}
          onClick={() => onTabChange('stats')}
        />
        
        {/* Primary Add Action embedded in dock */}
        <motion.button
          whileHover={maxHabitsReached ? {} : { scale: 1.05 }}
          whileTap={maxHabitsReached ? {} : { scale: 0.9 }}
          onClick={onAdd}
          className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center text-white mx-2 transition-colors duration-300",
            maxHabitsReached 
              ? "bg-slate-200 dark:bg-zinc-800 text-slate-400 dark:text-zinc-600 shadow-none" 
              : "bg-indigo-600 shadow-lg shadow-indigo-600/30"
          )}
        >
          <span className="material-icons-round">{maxHabitsReached ? "lock" : "add"}</span>
        </motion.button>
        
        <NavItem
          icon="settings"
          isActive={activeTab === 'settings'}
          onClick={() => onTabChange('settings')}
        />
      </nav>
    </div>
  );
}

function NavItem({ icon, isActive, onClick }: { icon: string, isActive: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative flex items-center justify-center w-12 h-12 rounded-full transition-colors",
        isActive ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 dark:text-zinc-500 hover:text-slate-600 dark:hover:text-zinc-300"
      )}
    >
      {isActive && (
        <motion.div 
          layoutId="dock-indicator"
          className="absolute inset-0 bg-indigo-50 dark:bg-indigo-500/10 rounded-full" 
        />
      )}
      <motion.span 
        animate={{ scale: isActive ? 1.1 : 1 }}
        className="material-icons-round relative z-10 text-[24px]"
      >
        {icon}
      </motion.span>
    </button>
  );
}
