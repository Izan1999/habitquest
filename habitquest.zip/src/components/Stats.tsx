import { Habit, Completion } from "../types";
import { format, subDays, isSameDay } from "date-fns";
import { t, locale } from "../lib/i18n";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { motion } from "motion/react";

interface StatsProps {
  habits: Habit[];
  completions: Completion[];
  xp: number;
  level: number;
  isDark: boolean;
  isPro?: boolean;
  onUpgrade?: () => void;
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const item = {
  hidden: { opacity: 0, y: 15 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
};

export function Stats({ habits, completions, xp, level, isDark, isPro = false, onUpgrade }: StatsProps) {
  const today = new Date();

  if (!isPro) {
    return (
      <div className="flex flex-col h-full px-6 md:px-12 pt-14 md:pt-20 pb-28 md:pb-32 justify-center items-center text-center">
         <motion.div 
           initial={{ scale: 0.9, opacity: 0, rotate: -15 }}
           animate={{ scale: 1, opacity: 1, rotate: 3 }}
           transition={{ type: "spring", stiffness: 200, damping: 20 }}
           className="bg-gradient-to-br from-amber-400 to-orange-500 w-24 h-24 rounded-[2rem] flex items-center justify-center text-white mb-8 shadow-xl shadow-orange-500/30"
         >
            <span className="material-icons-round text-[3.5rem]">auto_awesome</span>
         </motion.div>
         <h2 className="text-3xl font-extrabold text-slate-900 dark:text-zinc-50 mb-3 tracking-tight">{t.proStatsTitle}</h2>
         <p className="text-slate-500 dark:text-zinc-400 font-medium mb-10 text-[15px] leading-relaxed max-w-[260px]">
           {t.proStatsDesc}
         </p>
         <motion.button
           onClick={onUpgrade}
           whileHover={{ scale: 1.05 }}
           whileTap={{ scale: 0.95 }}
           className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold w-full max-w-[260px] py-4 rounded-2xl shadow-xl flex items-center justify-center gap-2"
         >
           <span className="material-icons-round text-amber-500">workspace_premium</span>
           <span>{t.unlockPro}</span>
         </motion.button>
      </div>
    );
  }
  
  const last7Days = Array.from({ length: 7 }).map((_, i) => {
    const d = subDays(today, 6 - i);
    const dateStr = format(d, "yyyy-MM-dd");
    const count = completions.filter(c => c.date === dateStr).length;
    
    return {
      day: format(d, "EEE", { locale }).substring(0, 3).toUpperCase(),
      date: format(d, "d MMM", { locale }),
      completions: count,
      total: habits.length,
      isToday: isSameDay(d, today)
    };
  });

  const totalCompletions = completions.length;
  let currentStreak = 0;
  for (let i = 0; i < 30; i++) {
    const d = subDays(today, i);
    const dateStr = format(d, "yyyy-MM-dd");
    const hasCompletedAny = completions.some(c => c.date === dateStr);
    if (i === 0 && !hasCompletedAny) continue;
    if (hasCompletedAny) currentStreak++;
    else break;
  }

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="flex flex-col h-full px-6 md:px-12 pt-14 md:pt-20 pb-28 md:pb-32 space-y-6 w-full max-w-5xl mx-auto"
    >
      <motion.header variants={item} className="shrink-0">
        <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-zinc-50">
          {t.progress}
        </h1>
      </motion.header>

      {/* Gamification Stats */}
      <motion.div variants={item} className="grid grid-cols-2 md:grid-cols-4 gap-3 shrink-0">
        <div className="bg-indigo-500 rounded-3xl p-4 text-white shadow-sm flex flex-col justify-between aspect-square md:aspect-auto md:h-[140px] relative overflow-hidden">
          <span className="material-icons-round text-2xl opacity-80 block">star</span>
          <div>
            <p className="text-indigo-100 text-[10px] font-bold uppercase tracking-wider">{t.level}</p>
            <p className="text-4xl font-extrabold tracking-tighter">{level}</p>
          </div>
          <div className="absolute -bottom-4 -right-4 opacity-10">
            <span className="material-icons-round text-[6rem]">star</span>
          </div>
        </div>
        
        <div className="bg-white dark:bg-[#18181b] rounded-3xl p-4 border border-slate-200 dark:border-zinc-800 shadow-md shadow-slate-200/60 dark:shadow-none flex flex-col justify-between aspect-square md:aspect-auto md:h-[140px] relative overflow-hidden text-slate-900 dark:text-zinc-50">
          <span className="material-icons-round text-2xl text-orange-500">local_fire_department</span>
          <div>
            <p className="text-slate-500 dark:text-zinc-400 text-[10px] font-bold uppercase tracking-wider">{t.streak}</p>
            <p className="text-4xl font-extrabold tracking-tighter">{currentStreak} <span className="text-base text-slate-400 font-bold -ml-1">{t.days}</span></p>
          </div>
          <div className="absolute -bottom-4 -right-4 opacity-[0.03] dark:opacity-[0.02]">
            <span className="material-icons-round text-[6rem]">local_fire_department</span>
          </div>
        </div>

        {/* Highlights line moved inside grid for tablets */}
        <div className="col-span-2 bg-white dark:bg-[#18181b] rounded-3xl p-4 md:p-6 border border-slate-200 dark:border-zinc-800 shadow-md shadow-slate-200/60 dark:shadow-none flex justify-between items-center md:h-[140px]">
           <div>
              <p className="text-[10px] font-bold text-slate-400 dark:text-zinc-500 uppercase tracking-wider">{t.accumulatedXp}</p>
              <p className="font-extrabold text-slate-800 dark:text-zinc-200 text-3xl md:text-4xl mt-1 tracking-tighter">{xp} <span className="text-lg text-slate-400 font-bold -ml-1">{t.xp}</span></p>
           </div>
           <div className="h-12 w-12 md:h-16 md:w-16 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl flex items-center justify-center shrink-0">
              <span className="material-icons-round text-indigo-500 text-3xl">auto_awesome</span>
           </div>
        </div>
      </motion.div>

      {/* Chart */}
      <motion.div variants={item} className="bg-white dark:bg-[#18181b] rounded-3xl p-5 border border-slate-200 dark:border-zinc-800 shadow-md shadow-slate-200/60 dark:shadow-none flex-1 min-h-[180px] flex flex-col">
        <div className="flex justify-between items-center mb-4 shrink-0">
          <h3 className="font-bold text-slate-800 dark:text-zinc-200">{t.activity}</h3>
          <span className="text-xs font-bold text-slate-400 dark:text-zinc-500">{totalCompletions} {t.totalStats}</span>
        </div>
        
        <div className="flex-1 w-full min-h-0">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={last7Days} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
              <XAxis 
                dataKey="day" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fill: isDark ? '#71717a' : '#94a3b8', fontWeight: 600 }} 
                dy={10}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fill: isDark ? '#52525b' : '#cbd5e1', fontWeight: 600 }}
                allowDecimals={false}
              />
              <Tooltip 
                cursor={{ fill: isDark ? 'rgba(39, 39, 42, 0.4)' : 'rgba(241, 245, 249, 0.4)' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold py-1 px-2 rounded block">
                        {data.completions}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="completions" radius={[4, 4, 4, 4]}>
                {last7Days.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.isToday ? '#6366f1' : (isDark ? '#27272a' : '#f1f5f9')} 
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </motion.div>
  );
}
