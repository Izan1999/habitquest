import { motion } from "motion/react";
import { t } from "../lib/i18n";
import { cn } from "../lib/utils";

interface SettingsProps {
  isDark: boolean;
  toggleDark: () => void;
  isPro?: boolean;
  onRequirePro?: () => void;
}

export function Settings({ isDark, toggleDark, isPro, onRequirePro }: SettingsProps) {
  return (
    <div className="flex flex-col h-full px-6 md:px-12 pt-14 md:pt-20 pb-28 md:pb-32 w-full max-w-5xl mx-auto">
       <header className="shrink-0 mb-8">
         <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-zinc-50">{t.settings}</h1>
       </header>
       
       <div className="flex-1 overflow-y-auto hide-scrollbar space-y-4 max-w-2xl w-full">
           {/* Dark Mode Toggle */}
           <div className="bg-white dark:bg-[#18181b] rounded-3xl p-2 border border-slate-200 dark:border-zinc-800 shadow-md shadow-slate-200/60 dark:shadow-none">
              <div className="flex items-center justify-between p-4">
                 <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-zinc-800 flex items-center justify-center text-slate-500 dark:text-zinc-400">
                       <span className="material-icons-round">dark_mode</span>
                    </div>
                    <span className="font-semibold text-slate-800 dark:text-zinc-200">{t.darkMode}</span>
                 </div>
                 <button 
                   onClick={() => {
                     if (!isPro && onRequirePro) {
                       onRequirePro();
                       return;
                     }
                     toggleDark();
                   }}
                   className={cn("w-14 h-8 rounded-full p-1 transition-colors duration-300 relative", isDark ? "bg-indigo-500" : "bg-slate-300 dark:bg-zinc-700")}
                 >
                   {!isPro && (
                     <div className="absolute inset-0 m-auto flex items-center justify-center opacity-70 z-10">
                        <span className="material-icons-round text-slate-50 text-[16px]">lock</span>
                     </div>
                   )}
                   <motion.div 
                     layout
                     animate={{ x: isDark ? 24 : 0 }}
                     className="w-6 h-6 bg-white rounded-full shadow-md"
                   />
                 </button>
              </div>
           </div>

           {/* Placeholder for Notifications */}
           <div className="bg-white dark:bg-[#18181b] rounded-3xl p-2 border border-slate-200 dark:border-zinc-800 shadow-md shadow-slate-200/60 dark:shadow-none">
              <div className="flex items-center justify-between p-4 opacity-50">
                 <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-zinc-800 flex items-center justify-center text-slate-500 dark:text-zinc-400">
                       <span className="material-icons-round">notifications</span>
                    </div>
                    <span className="font-semibold text-slate-800 dark:text-zinc-200">{t.reminders}</span>
                 </div>
                 <span className="text-[10px] font-bold text-slate-400 bg-slate-100 dark:bg-zinc-800 px-2 py-1 rounded-md">{t.soon}</span>
              </div>
           </div>
       </div>
    </div>
  );
}
