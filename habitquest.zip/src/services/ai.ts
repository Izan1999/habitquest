import { GoogleGenAI } from "@google/genai";
import { currentLang } from "../lib/i18n";

export async function generateMotivation(habitTitle: string): Promise<string> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const langSpec = currentLang === 'es' ? 'español' : 'inglés';
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Escribe una frase motivacional épica, corta y directa de máximo 8 a 10 palabras (en ${langSpec}) para animar a alguien a realizar el siguiente hábito: "${habitTitle}". No uses comillas ni explicaciones extra.`,
      config: {
        temperature: 0.7,
      }
    });
    return response.text?.trim() || "";
  } catch (error) {
    console.error("AI Gen Error:", error);
    return "";
  }
}
